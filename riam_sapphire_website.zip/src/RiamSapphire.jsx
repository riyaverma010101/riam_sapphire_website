
export default function RiamSapphire() {
  return (
    <div className="bg-pink-50 min-h-screen text-gray-800 font-sans">
      <header className="bg-white shadow p-4 flex justify-between items-center sticky top-0 z-10">
        <div className="flex items-center space-x-3">
          <img src="/logo.jpg" alt="Riam Sapphire Logo" className="h-12 w-12 rounded-full" />
          <h1 className="text-2xl font-bold text-pink-600">@riam_sapphire</h1>
        </div>
        <nav className="space-x-4">
          <a href="#home" className="hover:text-pink-500">Home</a>
          <a href="#about" className="hover:text-pink-500">About</a>
          <a href="#shop" className="hover:text-pink-500">Shop</a>
          <a href="#reviews" className="hover:text-pink-500">Reviews</a>
          <a href="#contact" className="hover:text-pink-500">Contact Us</a>
        </nav>
      </header>

      <section id="home" className="text-center py-16 px-4 bg-gradient-to-r from-pink-100 to-pink-50">
        <h2 className="text-4xl font-bold text-pink-700 mb-2">Feel the Glam</h2>
        <p className="text-lg text-gray-600 max-w-xl mx-auto">Premium 18k PVD Anti-Tarnish Jewelry – Bracelets, Earrings, Pendants, and Anklets to elevate your every day.</p>
      </section>

      <section id="about" className="px-6 py-12 bg-white text-center">
        <h3 className="text-3xl font-semibold text-pink-600 mb-4">About Us</h3>
        <p className="text-gray-700 max-w-2xl mx-auto">@riam_sapphire offers elegant, anti-tarnish 18k PVD jewelry. Our collection combines timeless design with lasting quality, perfect for your everyday glam.</p>
      </section>

      <section id="shop" className="px-6 py-12 bg-pink-50">
        <h3 className="text-3xl font-semibold text-pink-600 mb-8 text-center">Shop</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {['Bracelets', 'Earrings', 'Pendants', 'Anklets'].map((category) => (
            <div key={category} className="bg-white rounded-2xl shadow p-4 text-center">
              <h4 className="text-xl font-bold text-pink-500">{category}</h4>
              <p className="text-sm text-gray-600 mt-2">Shop elegant 18k {category.toLowerCase()} crafted for style & durability.</p>
              <button className="mt-4 px-4 py-2 bg-pink-600 text-white rounded-xl hover:bg-pink-700">View More</button>
            </div>
          ))}
        </div>
      </section>

      <section id="reviews" className="px-6 py-12 bg-white text-center">
        <h3 className="text-3xl font-semibold text-pink-600 mb-4">Customer Reviews</h3>
        <p className="text-gray-600 italic">"Absolutely in love with the quality and design!"</p>
        <p className="text-gray-600 italic mt-2">"My go-to brand for everyday jewelry now!"</p>
      </section>

      <section id="contact" className="px-6 py-12 bg-pink-50 text-center">
        <h3 className="text-3xl font-semibold text-pink-600 mb-4">Contact Us</h3>
        <p className="text-gray-700 mb-4">DM us on Instagram or WhatsApp for orders & inquiries.</p>
        <div className="flex justify-center space-x-4">
          <a href="https://instagram.com/riam_sapphire" className="text-pink-600 underline">Instagram</a>
          <a href="https://wa.me/your-number" className="text-pink-600 underline">WhatsApp</a>
        </div>
        <form className="mt-6 max-w-md mx-auto">
          <input type="text" placeholder="Your Name" className="block w-full mb-3 p-2 border rounded-xl" />
          <input type="email" placeholder="Your Email" className="block w-full mb-3 p-2 border rounded-xl" />
          <textarea placeholder="Your Message" className="block w-full mb-3 p-2 border rounded-xl" rows="4"></textarea>
          <button className="px-6 py-2 bg-pink-600 text-white rounded-xl hover:bg-pink-700">Send</button>
        </form>
      </section>

      <footer className="text-center py-6 text-sm text-gray-500 bg-white">© 2025 @riam_sapphire. All rights reserved.</footer>
    </div>
  );
}
